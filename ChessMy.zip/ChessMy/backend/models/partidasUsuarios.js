const { DataTypes } = require('sequelize');
const { sequelize } = require('../controllers/database');
